import java.util.ArrayList;

public class DifferenceDemo {

    public static void main(String[] args) {

        // Arrays have a fixed size once declared
        int[] numberArray = new int[5]; // Stores 5 integers
        numberArray[0] = 10;
        numberArray[1] = 20;
        numberArray[2] = 30;

        System.out.println("Array Elements:");
        for (int i = 0; i < numberArray.length; i++) {
            System.out.println("Index " + i + ": " + numberArray[i]);
        }

        // ArrayLists are resizable and can grow dynamically
        ArrayList<Integer> numberList = new ArrayList<>();
        numberList.add(10); // .add() method adds elements
        numberList.add(20);
        numberList.add(30);
        numberList.add(40); // No need to define size beforehand

        System.out.println("\nArrayList Elements:");
        for (int i = 0; i < numberList.size(); i++) {
            System.out.println("Index " + i + ": " + numberList.get(i)); // .get() retrieves elements
        }

        // Demonstrating dynamic resizing
        numberList.remove(1); // Removes element at index 1 (value 20)
        numberList.add(2, 99); // Inserts 99 at index 2

        System.out.println("\nArrayList After Modifications:");
        for (int num : numberList) {
            System.out.println(num);
        }

        // Summary of Differences
        System.out.println("\nSummary:");
        System.out.println("Arrays: fixed size, store primitives like int");
        System.out.println("ArrayLists: resizable, store objects like Integer");
    }
}